<?php
class Dosen_model extends CI_Model {
    public $nidn,
        $nama,
        $gender,
        $tmp_lahir,
        $tgl_lahir,
        $pendidikan,
        $matakuliah;
}