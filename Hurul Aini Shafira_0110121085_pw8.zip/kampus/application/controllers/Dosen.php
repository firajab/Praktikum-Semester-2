<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {
    public function index(){
        $this->load->model('dosen_model','dsn1');
        $this->dsn1->nidn=1001;
        $this->dsn1->nama="Bian Maulana";
        $this->dsn1->gender="L";
        $this->dsn1->pendidikan="S3";
        $this->dsn1->matakuliah="Ilmu Komunikasi";

        $this->load->model('dosen_model','dsn2');
        $this->dsn2->nidn=1002;
        $this->dsn2->nama="Ratu Putri Septiyanti";
        $this->dsn2->gender="P";
        $this->dsn2->pendidikan="S2";
        $this->dsn2->matakuliah="Bahasa Inggris";

        $list_dsn = [$this->dsn1,$this->dsn2];
        $data['list_dosen']=$list_dsn;

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/index',$data);
        $this->load->view('layout/footer');
    }

    public function create(){
        $data['judul']='Form Kelola Dosen';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        $this->load->model('dosen_model','dsn1');
        $this->dsn1->nidn=1001;
        $this->dsn1->nama="Bian Maulana";
        $this->dsn1->gender="L";
        $this->dsn1->pendidikan="S3";
        $this->dsn1->matakuliah="Ilmu Komunikasi";

        $this->load->model('dosen_model','dsn2');
        $this->dsn2->nidn=1002;
        $this->dsn2->nama="Ratu Putri Septiyanti";
        $this->dsn2->gender="P";
        $this->dsn2->pendidikan="S3";
        $this->dsn2->matakuliah="Bahasa Inggris";

        $this->load->model('dosen_model','dsn3');
        $this->dsn3->nidn = $this->input->post('nidn');
        $this->dsn3->nama = $this->input->post('nama');
        $this->dsn3->gender = $this->input->post('gender');
        $this->dsn3->tmp_lahir = $this->input->post('tmp_lahir');
        $this->dsn3->tgl_lahir = $this->input->post('tgl_lahir');
        $this->dsn3->pendidikan = $this->input->post('pendidikan');
        $this->dsn3->matakuliah = $this->input->post('matkul');

        $list_dsn = [$this->dsn1,$this->dsn2,$this->dsn3];
        $data['dsn3']=$this->dsn3;
        $data['list_dsn']=$list_dsn;

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/view',$data);
        $this->load->view('layout/footer');
    }
}